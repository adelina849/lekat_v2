<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>IMS Web Design</b> 1.0.0
    </div>
    <strong>Copyright &copy; <?php echo date("Y");?> <a href="http://quad.com">IMS Technology</a>.</strong> Your IT Solutions Partner.
</footer>